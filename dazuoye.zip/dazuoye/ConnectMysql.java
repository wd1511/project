//�������ݿ�
package dazuoye;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.LinkedList;
import java.sql.ResultSet;

public class ConnectMysql {
	private Connection conn;
	private Statement stmt;
	
	public ConnectMysql(){
		String username = System.getenv("ACCESSKEY");
		String password = System.getenv("SECRETKEY");
		/*System.getenv("MYSQL_HOST_S"); Ϊ�ӿ⣬ֻ��*/
		String dbUrl = String.format("jdbc:mysql://%s:%s/%s", System.getenv("MYSQL_HOST"), System.getenv("MYSQL_PORT"), System.getenv("MYSQL_DB"));
		try{
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			//System.out.println("f*ck");
			//conn = DriverManager.getConnection("jdbc:mysql://localhost/text?useSSL=false&characterEncoding=UTF-8", "root", "");
			//conn = DriverManager.getConnection("jdbc:mysql:// w.rdc.sae.sina.com.cn:3307/app_hitwd", "1jny5oxj0n", "zlxiwi24kk5m5zkjzh23l2h25zhxxihhw40l2k00");
			conn = DriverManager.getConnection(dbUrl, username, password);
			System.out.println("Mysql succeed!");
			//System.out.println("f*ck");
			stmt = conn.createStatement();
		}
		catch(Exception ex){
			System.out.println(ex);
			System.exit(0);
		}
	}
	
	/*public Paper[] getPaperFromAuthor(String str)
	{
		if(str.equals("")) return null;
		String sql =  "select * from Paper where author='" + str+"'";
		
	}*/
	
}