//�ο�����
package dazuoye;

import java.util.LinkedList;
import java.util.List;

public class Reference {
	private String paperName;  //������
	List<String> author;  //��������
	List<String> keyWords;  //�ؼ���
	private String sort1,sort2,sort3;  //123������
	private String publication;  //����
	private String workload; //����������
	private String date;  //ʱ��
	
	private int authorNum;//���ߵĸ���
	private int keyWordsNum;//�ؼ��ʸ���
	
	Reference()
	{
		author = new LinkedList<String>();
		keyWords = new LinkedList<String>();
		authorNum=0;
		keyWordsNum=0;
	}
	
	public void setPaperName(String str)
	{
		paperName=str;
	}
	
	public String getPaperName()
	{
		return paperName;
	}
	
	public void setSort1(String str)
	{
		sort1=str;
	}
	
	public String getSort1()
	{
		return sort1;
	}
	
	public void setSort2(String str)
	{
		sort1=str;
	}
	
	public String getSort2()
	{
		return sort2;
	}
	
	public void setSort3(String str)
	{
		sort3=str;
	}
	
	public String getSort3()
	{
		return sort3;
	}
	
	public void setPublication(String str)
	{
		publication=str;
	}
	
	public String getPublication()
	{
		return publication;
	}
	
	public void setWorkload(String str)
	{
		workload=str;
	}
	
	public String getWorkload()
	{
		return workload;
	}
	
	public void setDate(String str)
	{
		date=str;
	}
	
	public String getDate()
	{
		return date;
	}
	
}

