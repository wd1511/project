//�û��࣬�̳��ο�
package dazuoye;

import java.util.LinkedList;
import java.util.List;

public class User extends Tourist{
	private String username;
	private String password;
	List<String> collectedPapers;
	
	public void setUsername(String str)
	{
		username=str;
	}
	
	public String getUsername()
	{
		return username;
	}
	
	public void setPassword(String str)
	{
		password=str;
	}
	
	public String getPassword()
	{
		return password;
	}
	
}
