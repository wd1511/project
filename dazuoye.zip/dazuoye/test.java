package dazuoye;

import java.util.List;

public class test {
	public static void main(String[] arg) throws Exception {
		Paper paper=new Paper();
		System.out.println(150000);
		paper.author.add("1511");
		paper.author.add("1511");
		paper.author.add("1511");
		System.out.println(150000);
		System.out.println(paper.author.size());
		
	}
}
