package papermanege;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.LinkedList;
import java.sql.ResultSet;

public class ConnectMysql {
	private Connection conn;
	private Statement stmt;
	
	public ConnectMysql(){
		String username = "root";
		String password = "123456";
		String url="jdbc:mysql://localhost:3306/hx?useUnicode=true&characterEncoding=utf-8&useSSL=false";
		try{
		
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			conn = DriverManager.getConnection(url, username, password);
			stmt = conn.createStatement();
		}
		catch(Exception ex){
			System.out.println(ex);
			System.exit(0);
		}
	}
	
	//返回数据库连接conn
	public Connection retConnect(){
		return conn;
	}
	
	//返回论文的一级分类
	public LinkedList<String> paperSort1(){
		LinkedList<String> a=new LinkedList<String>();
		try{
			stmt = conn.createStatement(); 
			String sql= "select * from paper";
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next()){
				String s1=(String)rs.getString(5);
				if(!a.contains(s1))a.add(s1);
			}
			return a;
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return null;
	}
	
	//返回参考文献的一级分类
	public LinkedList<String> referenceSort1(){
		LinkedList<String> a=new LinkedList<String>();
		try{
			stmt = conn.createStatement(); 
			String sql= "select * from reference";
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next()){
				String s1=(String)rs.getString(5);
				if(!a.contains(s1))a.add(s1);
			}
			return a;
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return null;
	}
	
	//返回论文的二级分类
	public LinkedList<String> paperSort2(String sort1){
		LinkedList<String> a=new LinkedList<String>();
		try{
			stmt = conn.createStatement(); 
			String sql= "select * from paper";
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next()){
				String s1=(String)rs.getString(5);
				String s2=(String)rs.getString(6);
				if((s1.equals(sort1)) &&(!a.contains(s2)))a.add(s2);
			}
			return a;
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return null;
	}
	
	//返回参考文献的二级分类
	public LinkedList<String> referenceSort2(String sort1){
		LinkedList<String> a=new LinkedList<String>();
		try{
			stmt = conn.createStatement(); 
			String sql= "select * from reference";
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next()){
				String s1=(String)rs.getString(5);
				String s2=(String)rs.getString(6);
				if((s1.equals(sort1)) &&(!a.contains(s2)))a.add(s2);
			}
			return a;
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return null;
	}
	
	//返回论文的三级分类
	public LinkedList<String> paperSort3(String sort2){
		LinkedList<String> a=new LinkedList<String>();
		try{
			stmt = conn.createStatement(); 
			String sql= "select * from paper";
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next()){
				String s1=(String)rs.getString(6);
				String s2=(String)rs.getString(7);
				if((s1.equals(sort2)) &&(!a.contains(s2)))a.add(s2);
			}
			return a;
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return null;
	}
	
	//返回参考文献的三级分类
	public LinkedList<String> referenceSort3(String sort2){
		LinkedList<String> a=new LinkedList<String>();
		try{
			stmt = conn.createStatement(); 
			String sql= "select * from reference";
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next()){
				String s1=(String)rs.getString(6);
				String s2=(String)rs.getString(7);
				if((s1.equals(sort2)) &&(!a.contains(s2)))a.add(s2);
			}
			return a;
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return null;
	}
	
	//三级论文展示
	public LinkedList<Paper> paperShow(String sort3){
		LinkedList<Paper> a=new LinkedList<Paper>();
		try{
			stmt = conn.createStatement(); 
			String sql= "select * from paper";
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next()){
				String s1=(String)rs.getString(7);
				if(s1.equals(sort3)){
				Paper p=new Paper((int)rs.getInt(1),(String)rs.getString(2),(String)rs.getString(3),
				(String)rs.getString(4),(String)rs.getString(5),(String)rs.getString(6),(String)rs.getString(7),
				(String)rs.getString(8),(String)rs.getString(9),(String)rs.getString(10),(String)rs.getString(11));
				a.add(p);
				}
			}
			return a;
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return null;
	}
		
}