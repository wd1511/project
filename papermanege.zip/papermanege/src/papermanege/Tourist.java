package papermanege;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.LinkedList;
import java.sql.ResultSet;

public class Tourist {
	public Tourist(){
	;
	}
	
	public void paperSort1(){
		ConnectMysql cmysql=new ConnectMysql();
		Connection conn=cmysql.retConnect();
	}
	
	public void paperSort2(){
		;
	}
	
	public void paperSort3(){
		;
	}
	
	public void paperRead(){
		;
	}
	
	public void referenceSort1(){
		;
	}
	
	public void referenceSort2(){
		;
	}
	
	public void referenceSort3(){
		;
	}
	
	public void referenceRead(){
		;
	}
	
	public void searchPaper(){
	;
	}
	
	public void searchReference(){
	;
	}
	
	public void relationshipNetwork(){
	;
	}
	
}
