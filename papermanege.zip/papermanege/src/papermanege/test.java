package papermanege;
import java.util.List;

public class test {
	public static void main(String[] arg) throws Exception {
		Manager m=new Manager();
		//System.out.println(m.deleteUser(1));
		//m.addUser(1,"wnaghanzhang","123456");
		//System.out.println(m.showUser(1).getUsername());
		User p=new User(1,"a","b");
		m.modifyUser(p);
	}
}
